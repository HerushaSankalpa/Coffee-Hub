<?php 

include("connection.php");
if(isset($_POST['Log in'])){

$username = $_POST["Username"];
$password = $_POST["Password"];

$sql = "select" from login where username = '$username' and password = '$password';
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_array($result, MYSQLI_ASSOC);
$count = mysqli_num_rows($result);
if ($count==1){
	header("Location:admin.php");
}
else{
	echo '<script>
		window.location.href = "login.php";
		alert("Login Failed");
		</script>';
}
}


}

?>